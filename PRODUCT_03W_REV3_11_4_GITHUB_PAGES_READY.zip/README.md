# Site Control | Engineering AI Hub Product 03W | REV 3.11.4

Standalone static web application for GitHub Pages; based on the previously developed REV 3.11.3 version. This package preserves the current app engine and adds a ten-language in-app help panel (17 sections). **This is not a new/rebuilt app**.

## GitHub Pages deployment
1. Create a **new public** GitHub repository named `engineering-ai-hub-product-03w` (keep Product 01 in its existing repository).
2. Unzip this archive and upload its *contents* to the repository root; do **not** upload the ZIP alone. For the minimal web app, `index.html` is sufficient, but the guide's Turkish PDF link also needs `PROFESYONEL_GORSELLI_KILAVUZ_TR.pdf` uploaded at the same level.
3. Go to Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/ (root)` → Save.
4. After GitHub Pages finishes publishing, open the published site (expected account/repo format `https://zshakiri123-coder.github.io/engineering-ai-hub-product-03w/`). Verify the on-screen version and visit `/version.txt`.

**Important:** GitHub Pages publishing is public. Do **not** commit actual site logs, invoices, signatures, private project backups, or JSON data. Sample data in the application is illustrative only. Keep JSON backups securely offline; a new site origin has separate localStorage, and existing Netlify user data does not automatically transfer.

## Tests and limits
- Static checks: single-page HTML structure; 6 embedded scripts pass `node --check`; 10 localized help catalogues × 17 sections; link target present; version marker.
- **Not verified:** real Safari interaction, GitHub Pages publication, end-to-end live project workflow, official engineering approval, or bidirectional Excel sync.
- The 18-page illustrated PDF is Turkish-only and uses screenshots from REV 3.11.2. Ten-language in-app guidance is separate.
