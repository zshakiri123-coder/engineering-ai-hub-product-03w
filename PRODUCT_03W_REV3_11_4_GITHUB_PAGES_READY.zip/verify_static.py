from pathlib import Path
from zipfile import ZipFile
from html.parser import HTMLParser
import re, subprocess, tempfile
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text('utf-8')
assert '3.11.4' in html
assert (root/'version.txt').read_text().find('3.11.4')>=0
assert (root/'PROFESYONEL_GORSELLI_KILAVUZ_TR.pdf').read_bytes()[:4]==b'%PDF'
class Scripts(HTMLParser):
 def __init__(self): super().__init__();self.inscript=False;self.scripts=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script':self.inscript=True;self.scripts.append('')
 def handle_endtag(self,tag):
  if tag=='script':self.inscript=False
 def handle_data(self,data):
  if self.inscript:self.scripts[-1]+=data
p=Scripts();p.feed(html)
assert len(p.scripts)==6
with tempfile.TemporaryDirectory() as d:
 for i,script in enumerate(p.scripts):
  f=Path(d)/(str(i)+'.js');f.write_text(script)
  subprocess.run(['node','--check',str(f)],check=True)
assert 'site-guide-dialog' in html
assert 'PROFESYONEL_GORSELLI_KILAVUZ_TR.pdf' in html
print('STATIC CHECK PASS — version, HTML, scripts and PDF')
