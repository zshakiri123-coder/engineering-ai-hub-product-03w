# PRODUCT 03W — GITHUB PAGES YAYIN KILAVUZU (REV 3.11.4)

## İlk işlem: yedek
Eski Netlify sitesini silmeyin. Önce oradaki gerçek proje verilerinizi Proje / Dosya → Projeyi JSON indir üzerinden yedekleyin. JSON dosyalarını herkese açık GitHub deposuna ASLA koymayın.

## Bir kere oluşturulacak depo
1. Safari'de https://github.com/new adresini açın; GitHub hesabınızla giriş yapın.
2. Repository name alanına `engineering-ai-hub-product-03w` yazın.
3. Public seçin, Add a README işaretleyebilirsiniz; Create repository düğmesine basın.
4. Oluşan depoda Add file → Upload files yolunu açın. Bu paketteki `index.html` dosyasını seçip Commit changes ile kaydedin. iPhone tek dosya seçtiriyorsa sonraki dosyaları ayrı ayrı yükleyin. İsteğe bağlı PDF rehberinin bağlantısının çalışması için `PROFESYONEL_GORSELLI_KILAVUZ_TR.pdf` dosyasını da yükleyin. `version.txt` doğrulama için yararlıdır.
5. GitHub sayfasında Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main → Folder: / (root) → Save.
6. GitHub Pages sayfasının gösterdiği **gerçek yayımlanmış bağlantıyı** açın. Adres örneği: https://zshakiri123-coder.github.io/engineering-ai-hub-product-03w/
7. Ekranda `REV 3.11.4` ve `Yardım / Help` göründüğünü, Yardım'ın 10 dilde açıldığını test edin. Henüz yayımlanmadan bu örnek URL'nin çalışacağı garanti edilemez.

## Önemli notlar
- ZIP'i doğrudan depoya tek dosya olarak yüklemek siteyi açmaz: ZIP **çıkarılmış** olmalıdır.
- Eski Netlify sitesindeki proje kayıtları yeni GitHub Pages adresine **otomatik taşınmaz**; gerçek projeyi açmadan önce JSON içeri al yapmalısınız.
- Yeni depoya gerçek müşteri veya proje bilgilerini, maliyet tablolarını ya da resmî onay belgelerini yüklemeyin.
- GitHub Pages ücretsiz yayın için Public repo gerekir (plan detaylarını hesabınızda doğrulayın).
- Site Control'deki SSOT doğrulama ve saha onayları otomatik resmî mühendis onayı değildir.
