const assert=require('node:assert/strict');
const E=require('./siteengine.js');
console.log('Engine exports',Object.keys(E));
const p=E.newProject();
p.project.name='Site Control Test 001';p.project.number='TEST-SC-001';
p.tasks.push({id:'T-001', title:'Temel betonu',qty:10,budget:2400,unit:'m³',start:p.project.reportDate,finish:p.project.reportDate,baselineHours:80});
p.daily.push({id:'DAY-001',date:p.project.reportDate,taskId:'T-001',qty:4,hours:8,people:1,cost:900,attachments:[{id:'IMG-A',name:'test.jpg',type:'image/jpeg',size:3,data:'data:image/jpeg;base64,/9j/'}]});
const calc=E.calc(p);assert.equal(calc.BAC,2400);assert.equal(calc.EV,960);assert.equal(calc.AC,900);assert.equal(calc.progress,0.4);
const imported=E.safeImport(JSON.parse(JSON.stringify(p)));assert.equal(imported.daily[0].attachments.length,1);assert.equal(imported.project.name,p.project.name);
for(const bad of [[],[{id:'x',name:'attack',type:'image/jpeg',size:3,data:'javascript:alert(1)'}]]){
 let attack=JSON.parse(JSON.stringify(p));attack.daily[0].attachments=bad;
 if(bad.length){assert.throws(()=>E.safeImport(attack),/fotoğraf/i);}
}
console.log('PASSED: engine calculation, project preservation, attachment backup parsing, imported URL validation');
