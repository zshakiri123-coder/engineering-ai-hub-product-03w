# Site Control — Product 03W, REV 3.11.5

**Updated from the existing REV 3.11.4, not recreated.** Professional offline-capable one-file web app for active construction projects.

### Changes in 3.11.5

- Clearly shows the **active project name and project code** in the main header, project identity strip, and Project / Files section, retaining the exact user-entered name in all languages.
- Separates the optional sample-project template from active project identification; the optional sample-loading banner hides once the active project has work items.
- Adds **Take photo**, **Choose from Photos / Files**, and **Remove attachment** to the **Daily Log / Saha Günlüğü** form.
- Compresses images on-device, allows PNG/JPEG/WebP/decodable HEIC images and small PDF files, embeds records with their active project's daily entry, and includes photo evidence in JSON backup and restore.
- Keeps quantity, cost and SSOT calculation engines unchanged; does not auto-approve safety / QA / field gates from photographs alone.
- Includes UI labels in 10 languages. Screenshot guide is from an earlier version; the extra attachment controls are documented here.

### Data protection and limits

Images are compressed and stored **locally as part of the project data** in this version. Up to four attachments per daily entry, and approximately 2 MB of compressed attachment data per active project. Maximum supported PDF size is about 450 KB. Keep original full-resolution photo/PDF files separately. Export a **full JSON backup** after recording or editing photos. CSV exports do not contain embedded image data. Using **New real project** replaces the active project in that browser, so export JSON first. Clearing Safari website data removes local storage. This app does **not** sync automatically between devices.

### Deploy on GitHub Pages

The root `index.html` is the standalone application. GitHub Pages: `Settings → Pages → Deploy from a branch → main → / (root)`. The default public site is `https://zshakiri123-coder.github.io/engineering-ai-hub-product-03w/` (when publication completes).

### Quality checks

- 6 JavaScript source blocks passed `node --check` syntax validation.
- Existing `SiteEngine` calculations verified on a controlled test: planned 10 m³, completed 4 m³, BAC CAD 2,400, EV CAD 960, AC CAD 900.
- `safeImport` JSON structure/attachment round-trip and rejection of unsafe data URLs passed a Node.js regression test.
- **Physical iPhone camera picker, storage quota, Safari download, and published GitHub Pages UI have not been verified yet**. They must be manually tested before calling production PASS.

No third-party dependencies or account/API keys. The app is not a substitute for authorized field verification.
