/* Product 03W • Site Control engine. Deterministic, no network, no dependencies. */
(function(root,factory){const lib=factory();if(typeof module==='object'&&module.exports)module.exports=lib;root.SiteEngine=lib;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const R=v=>Math.round((Number(v)+Number.EPSILON)*1e8)/1e8;
const number=v=>Number.isFinite(Number(v))?Number(v):0;
const validDate=s=>typeof s==='string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s+'T12:00:00Z'));
const sortDate=(a,b)=>a.localeCompare(b);
function workdays(start,end){if(!validDate(start)||!validDate(end)||start>end)return 0;let t=Date.parse(start+'T12:00:00Z'),last=Date.parse(end+'T12:00:00Z'),n=0;for(;t<=last;t+=86400000){const d=new Date(t).getUTCDay();if(d!==0&&d!==6)n++;if(n>36500)break;}return n;}
function plannedFraction(t,asof){if(!validDate(asof)||!validDate(t.start)||!validDate(t.finish)||t.start>t.finish)return 0;if(asof<t.start)return 0;if(asof>=t.finish)return 1;const all=workdays(t.start,t.finish);if(all===0)return 0;return Math.min(1,Math.max(0,workdays(t.start,asof)/all));}
function newProject(){return {schema:3,mode:'REAL',project:{name:'Yeni şantiye projesi',number:'',currency:'CAD',reportDate:(()=>{const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10);})(),standardHours:8},tasks:[],daily:[],costs:[],qa:[],rfis:[],materials:[],equipment:[],labor:[],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};}
function calc(st){const reportDate=st.project?.reportDate||'';const tasks=st.tasks||[], daily=st.daily||[],costs=st.costs||[];
const actual={};const hours={};const logCosts={};for(const l of daily){if(validDate(l.date)&&l.date<=reportDate){let k=l.taskId;actual[k]=(actual[k]||0)+Math.max(0,number(l.qty));hours[k]=(hours[k]||0)+Math.max(0,number(l.hours));logCosts[k]=(logCosts[k]||0)+Math.max(0,number(l.cost));}}
let BAC=0,EV=0,PV=0,earnedHours=0;const items=[];
for(const t of tasks){const qty=Math.max(0,number(t.qty)),budget=Math.max(0,number(t.budget)),done=Math.max(0,number(actual[t.id]||0));const completion=qty>0?Math.min(1,done/qty):0;const planned=plannedFraction(t,reportDate);const earned=budget*completion;BAC+=budget;EV+=earned;PV+=budget*planned;earnedHours+=Math.max(0,number(t.baselineHours))*completion;items.push({...t,actualQty:R(done),completion:R(completion),planned:R(planned),earned:R(earned)});}
const AC= daily.filter(l=>validDate(l.date)&&l.date<=reportDate).reduce((n,l)=>n+Math.max(0,number(l.cost)),0)+costs.filter(c=>validDate(c.date)&&c.date<=reportDate).reduce((n,c)=>n+Math.max(0,number(c.amount)),0);
const actualHours=daily.filter(l=>validDate(l.date)&&l.date<=reportDate).reduce((n,l)=>n+Math.max(0,number(l.hours)),0);
return {BAC:R(BAC),EV:R(EV),PV:R(PV),AC:R(AC),CPI:AC>0?R(EV/AC):null,SPI:PV>0?R(EV/PV):null,progress:BAC>0?R(EV/BAC):0,plannedProgress:BAC>0?R(PV/BAC):0,actualHours:R(actualHours),earnedHours:R(earnedHours),items};}
function gates(st){const tasks=st.tasks||[],daily=st.daily||[],qa=st.qa||[];const standardHours=number(st.project?.standardHours)||8;
const qtoOpen=tasks.filter(t=>!(number(t.qty)>0&&number(t.budget)>=0&&t.sourceRef?.trim()&&t.qtoChecker?.trim()&&t.qtoApproved===true));
const overtime=daily.filter(l=>number(l.hours)>number(l.people)*standardHours).filter(l=>!(l.overtimeApproved===true&&l.overtimeRef?.trim()));
const qaOpen=qa.filter(q=>!(q.status==='PASS'&&q.evidence?.trim()&&q.inspector?.trim()));
const baselineOpen=tasks.filter(t=>!(validDate(t.start)&&validDate(t.finish)&&t.start<=t.finish&&number(t.baselineHours)>=0&&t.baselineApproved===true&&t.baselineRef?.trim()));
const ssotOpen=tasks.filter(t=>!(t.ssotVerified===true&&t.ssotRef?.trim()&&t.ssotChecker?.trim()));
const rows=[
 {code:'CHK-006',title:'QTO / metraj kaynağı',open:tasks.length? qtoOpen.length:1,issue:tasks.length?`${qtoOpen.length} iş kalemi kaynak/doğrulama bekliyor`:'En az bir gerçek iş kalemi gerekli',done:tasks.length-qtoOpen.length,section:'qto'},
 {code:'CHK-008',title:'Fazla mesai ve vardiya',open:overtime.length,issue:`${overtime.length} izinsiz fazla mesai kaydı`,done:daily.length-overtime.length,section:'daily'},
 {code:'CHK-010',title:'QA / QC kontrol kapaması',open:qa.length?qaOpen.length:1,issue:qa.length?`${qaOpen.length} denetim açık veya belgesiz`:'En az bir denetim kaydı gerekli',done:qa.length-qaOpen.length,section:'quality'},
 {code:'CHK-014',title:'Onaylı CPM baseline',open:tasks.length?baselineOpen.length:1,issue:tasks.length?`${baselineOpen.length} başlangıç/bitiş veya onay eksik`:'Onaylı baseline gerekli',done:tasks.length-baselineOpen.length,section:'qto'},
 {code:'CHK-015',title:'Bağımsız SSOT kontrolü',open:tasks.length?ssotOpen.length:1,issue:tasks.length?`${ssotOpen.length} doğrulama eksik`:'En az bir doğrulanmış kayıt gerekli',done:tasks.length-ssotOpen.length,section:'qto'},
 ];return {rows,allPass:rows.every(r=>r.open===0),holdCount:rows.filter(r=>r.open>0).length};}
function issues(st){const found=[];const tasks=st.tasks||[];const ids=new Set();for(const t of tasks){if(!t.id||ids.has(t.id))found.push(`Tekrarlı veya boş iş kodu: ${t.id||'—'}`);ids.add(t.id);if(!(number(t.qty)>0))found.push(`${t.id}: miktar sıfır veya geçersiz`);if(!(number(t.budget)>=0))found.push(`${t.id}: bütçe negatif`);if(t.finish&&t.start&&t.start>t.finish)found.push(`${t.id}: bitiş başlangıçtan önce`);}
for(const l of st.daily||[])if(!ids.has(l.taskId))found.push(`${l.id}: bilinmeyen iş kodu`);
for(const c of st.costs||[])if(c.taskId&&!ids.has(c.taskId))found.push(`${c.id}: bilinmeyen maliyet iş kodu`);
return found;}
function release(st){const g=gates(st),problems=issues(st);return {status:st.project?.isExample?'HOLD':g.allPass&&problems.length===0?'PASS':'HOLD',gates:g.rows,holdCount:g.holdCount,problems,calculation:calc(st)};}
function safeImport(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||!value.project||typeof value.project!=='object'||value.schema!==3)throw Error('Geçersiz veya uyumsuz Product 03W JSON şeması');
 const sections=['tasks','daily','costs','qa','rfis','materials','equipment','labor'];
 const result=JSON.parse(JSON.stringify(value));
 for(const section of sections){if(result[section]===undefined)result[section]=[];if(!Array.isArray(result[section]))throw Error(section+' bir kayıt listesi olmalıdır');if(result[section].length>100000)throw Error(section+' için aşırı kayıt sayısı');for(const row of result[section])if(!row||typeof row!=='object'||Array.isArray(row))throw Error(section+' içinde geçersiz kayıt');}
 if(result.tasks.length>10000)throw Error('Çok fazla iş kalemi');
 let importedEvidenceBytes=0;for(const l of result.daily){if(l.attachments!==undefined){if(!Array.isArray(l.attachments)||l.attachments.length>4)throw Error('Günlük fotoğraf listesi geçersiz');for(const a of l.attachments){if(!a||typeof a!=='object'||typeof a.id!=='string'||typeof a.name!=='string'||typeof a.type!=='string'||!Number.isFinite(a.size)||!/^data:(?:image\/(?:jpeg|png|webp)|application\/pdf);base64,[A-Za-z0-9+/=]+$/.test(a.data||'')||a.data.length>800000)throw Error('Geçersiz fotoğraf / belge eki');importedEvidenceBytes+=a.data.length;}}}if(importedEvidenceBytes>2800000)throw Error('Fotoğraf yedeği depolama sınırını aşıyor');
 
 // Validate each module before replacing the current project.
 // This does not constitute engineering approval of imported records.
 if(!result.project.reportDate || !validDate(result.project.reportDate)) throw Error('Geçersiz proje rapor tarihi');
 const numericFields={tasks:['qty','budget','unitRate','baselineHours','length','width','depth','count'],daily:['qty','hours','people','cost','temperature'],costs:['amount'],materials:['qty','unitCost'],equipment:['hours','idleHours','rate','fuel'],labor:['crew','hours','rate','overtime']};
 for(const section of sections){
   const seen=new Set();
   for(const rec of result[section]){
     if(typeof rec.id!=='string'||!rec.id.trim()||rec.id.length>120) throw Error(section+' içinde geçersiz/boş kayıt kimliği');
     if(seen.has(rec.id)) throw Error(section+' içinde tekrarlı kayıt: '+rec.id);
     seen.add(rec.id);
     for(const key of (numericFields[section]||[])) if(rec[key]!==undefined && rec[key]!==null && rec[key]!=='' && (!Number.isFinite(Number(rec[key])) || (key!=='temperature' && Number(rec[key])<0)))throw Error(section+' / '+rec.id+' : geçersiz '+key);
     if(typeof rec.taskId==='string'&&rec.taskId.length>120)throw Error(section+' / '+rec.id+' : geçersiz iş kodu');
   }
 }
 const ids=new Set(result.tasks.map(t=>t.id));
 for(const section of ['daily','costs','qa','rfis','materials','equipment','labor'])for(const record of result[section])if(record.taskId&&!ids.has(record.taskId))throw Error(section+' içinde bilinmeyen iş kodu: '+record.taskId);
 result.project.unitSystem='SI';
 return result;
}

return {newProject,calc,gates,issues,release,workdays,plannedFraction,validDate,safeImport,number,R};
});
